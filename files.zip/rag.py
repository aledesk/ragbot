"""
rag.py — Motor de búsqueda RAG + FastAPI
Recibe una pregunta → busca chunks relevantes → Claude genera respuesta
"""

import chromadb
import pickle
import numpy as np
import anthropic
import re
from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel

# ── Config ────────────────────────────────────────────────────────────────────
CHROMA_PATH     = "./chroma_db"
COLLECTION_NAME = "mayorista_docs"
VECTOR_DIM      = 384
TOP_K           = 4       # chunks a recuperar por query
MODEL           = "claude-sonnet-4-20250514"

SYSTEM_PROMPT = """Sos el asistente de ventas de Distribuidora Norte.
Respondés preguntas de clientes y revendedores usando ÚNICAMENTE la información del catálogo y las condiciones comerciales que se te proporcionan como contexto.

Reglas:
- Si la información está en el contexto, respondé con precisión y detalle.
- Si no está en el contexto, decí claramente: "No tengo esa información en el catálogo actual."
- Nunca inventes precios, stocks o condiciones.
- Usá un tono profesional pero cercano.
- Si hay precios, siempre aclará la moneda (USD).
- Podés recomendar productos alternativos si pregunta por algo que no está.
- Respondé en español rioplatense (vos, ustedes)."""

# ── Inicialización ────────────────────────────────────────────────────────────
app = FastAPI(title="RAG Mayorista API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Cargar ChromaDB y vectorizer al inicio
chroma_client  = chromadb.PersistentClient(path=CHROMA_PATH)
collection     = chroma_client.get_collection(name=COLLECTION_NAME)
anthropic_client = anthropic.Anthropic()

with open(f"{CHROMA_PATH}/vectorizer.pkl", "rb") as f:
    vectorizer: TfidfVectorizer = pickle.load(f)

print("✅ RAG backend listo")


# ── Helpers ───────────────────────────────────────────────────────────────────
def embed_query(query: str) -> list[float]:
    mat = vectorizer.transform([query])
    arr = np.array(mat.todense()).flatten()
    arr = arr[:VECTOR_DIM] if len(arr) >= VECTOR_DIM else np.pad(arr, (0, VECTOR_DIM - len(arr)))
    norm = np.linalg.norm(arr)
    return (arr / norm if norm > 0 else arr).tolist()


def recuperar_contexto(query: str) -> tuple[str, list[dict]]:
    embedding = embed_query(query)
    results = collection.query(
        query_embeddings=[embedding],
        n_results=TOP_K,
        include=["documents", "metadatas", "distances"],
    )
    chunks   = results["documents"][0]
    metas    = results["metadatas"][0]
    distancias = results["distances"][0]

    fuentes = []
    contexto_parts = []
    for i, (chunk, meta, dist) in enumerate(zip(chunks, metas, distancias)):
        contexto_parts.append(f"[Fragmento {i+1} — Página {meta['page']}]\n{chunk}")
        fuentes.append({"page": meta["page"], "source": meta["source"], "relevancia": round(1 - dist, 3)})

    return "\n\n---\n\n".join(contexto_parts), fuentes


def generar_respuesta(pregunta: str, contexto: str) -> str:
    prompt = f"""Contexto del catálogo:\n\n{contexto}\n\n---\n\nPregunta del cliente: {pregunta}"""
    response = anthropic_client.messages.create(
        model=MODEL,
        max_tokens=800,
        system=SYSTEM_PROMPT,
        messages=[{"role": "user", "content": prompt}],
    )
    return response.content[0].text


# ── Endpoints ─────────────────────────────────────────────────────────────────
class QueryRequest(BaseModel):
    pregunta: str
    historial: list[dict] = []   # [{role, content}] para multi-turn futuro


class QueryResponse(BaseModel):
    respuesta: str
    fuentes: list[dict]
    pregunta: str


@app.post("/api/chat", response_model=QueryResponse)
def chat(req: QueryRequest):
    if not req.pregunta.strip():
        raise HTTPException(400, "La pregunta no puede estar vacía")
    contexto, fuentes = recuperar_contexto(req.pregunta)
    respuesta = generar_respuesta(req.pregunta, contexto)
    return QueryResponse(respuesta=respuesta, fuentes=fuentes, pregunta=req.pregunta)


@app.get("/api/health")
def health():
    return {"status": "ok", "chunks_indexados": collection.count()}


# Servir frontend estático si existe
frontend_path = Path("../frontend/dist")
if frontend_path.exists():
    app.mount("/", StaticFiles(directory=str(frontend_path), html=True), name="static")

